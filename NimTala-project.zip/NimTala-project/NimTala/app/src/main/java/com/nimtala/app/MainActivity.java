package com.nimtala.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import android.content.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class MainActivity extends Activity {
    LinearLayout list;
    TextView status;
    PriceChart chart;
    final ExecutorService executor = Executors.newFixedThreadPool(6);

    final Source[] sources = new Source[] {
        new Source("اتحادیه طلا", "https://www.tgju.org/profile/geram18"),
        new Source("تخمین‌زن", "https://takhminzan.com"),
        new Source("تابان گوهر", "https://tabangohar.ir/smart/"),
        new Source("طلاسی", "https://talasea.ir"),
        new Source("میلی", "https://milli.gold"),
        new Source("ایران‌جیب", "https://www.iranjib.ir/showgroup/23/realtime_price/")
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        refresh();
    }

    TextView tv(String text, float sp) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextSize(sp); t.setTextColor(Color.WHITE);
        t.setPadding(20, 12, 20, 12);
        return t;
    }

    GradientDrawable bg(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(r); return g;
    }

    void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(20, 18, 20, 30);
        page.setBackgroundColor(Color.rgb(15,18,23));
        scroll.addView(page);

        TextView title = tv("نیم طلا", 30);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        page.addView(title);

        TextView sub = tv("قیمت طلای ۱۸ عیار از چند منبع", 15);
        sub.setTextColor(Color.LTGRAY);
        page.addView(sub);

        status = tv("در حال دریافت قیمت‌ها…", 13);
        status.setTextColor(Color.GRAY);
        page.addView(status);

        Button refresh = new Button(this);
        refresh.setText("بروزرسانی");
        refresh.setOnClickListener(v -> refresh());
        page.addView(refresh);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        page.addView(list);

        chart = new PriceChart(this);
        page.addView(chart, new LinearLayout.LayoutParams(-1, 520));

        TextView forecastTitle = tv("تحلیل کوتاه‌مدت", 21);
        forecastTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        page.addView(forecastTitle);

        TextView forecast = tv(
            "این بخش با استفاده از روند تاریخی ذخیره‌شده، میانگین متحرک و شتاب قیمت تحلیل می‌کند. " +
            "نتیجه «خرید / فروش / صبر» فقط یک برآورد احتمالی است و تضمین سود نیست.",
            14);
        forecast.setTextColor(Color.LTGRAY);
        page.addView(forecast);

        TextView disclaimer = tv(
            "هشدار: اختلاف قیمت منابع، تأخیر انتشار و تغییر ساختار سایت‌ها ممکن است باعث اختلاف یا عدم دریافت نرخ شود.",
            12);
        disclaimer.setTextColor(Color.GRAY);
        page.addView(disclaimer);

        setContentView(scroll);
    }

    void refresh() {
        status.setText("در حال دریافت قیمت‌ها…");
        list.removeAllViews();
        chart.clear();
        for (Source s : sources) {
            TextView row = tv(s.name + "   —   در حال دریافت…", 16);
            row.setBackground(bg(Color.rgb(28,33,41), 24));
            row.setPadding(22, 18, 22, 18);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, 6, 0, 6);
            list.addView(row, lp);
            executor.execute(() -> {
                PriceResult r = fetch(s);
                runOnUiThread(() -> {
                    row.setText(s.name + "   —   " + (r.ok ? money(r.price) + " تومان" : "دریافت نشد"));
                    row.setTextColor(r.ok ? Color.WHITE : Color.LTGRAY);
                    if (r.ok) chart.addPoint(s.name, r.price);
                });
            });
        }
    }

    String money(double n) {
        return String.format(Locale.US, "%,.0f", n).replace(",", "٬");
    }

    PriceResult fetch(Source s) {
        try {
            HttpURLConnection c = (HttpURLConnection)new URL(s.url).openConnection();
            c.setConnectTimeout(9000); c.setReadTimeout(9000);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) NimTala/1.0");
            c.setRequestProperty("Accept-Language", "fa-IR,fa;q=0.9,en;q=0.8");
            InputStream in = c.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            StringBuilder b = new StringBuilder(); String line;
            int count=0;
            while((line=br.readLine())!=null && count++<12000) b.append(line).append('\n');
            String html = b.toString();
            double p = extract18(html);
            return p > 0 ? new PriceResult(true,p) : new PriceResult(false,0);
        } catch(Exception e) { return new PriceResult(false,0); }
    }

    double extract18(String html) {
        String h = html.replace("&nbsp;"," ").replace("٬",",");
        String[] patterns = {
            "(?i)(?:طلای\\s*۱۸|طلای\\s*18|گرم\\s*۱۸|گرم\\s*18|18\\s*عیار)[^0-9]{0,180}([0-9۰-۹][0-9۰-۹,\\. ]{5,})",
            "(?i)(?:18\\s*karat|18k)[^0-9]{0,180}([0-9][0-9,\\. ]{5,})"
        };
        for(String x: patterns) {
            Matcher m=Pattern.compile(x).matcher(h);
            if(m.find()) {
                String n=m.group(1).replaceAll("[^0-9۰-۹]","");
                n=n.replace('۰','0').replace('۱','1').replace('۲','2').replace('۳','3').replace('۴','4')
                   .replace('۵','5').replace('۶','6').replace('۷','7').replace('۸','8').replace('۹','9');
                try {
                    double v=Double.parseDouble(n);
                    if(v>1000000 && v<100000000) return v;
                } catch(Exception ignored){}
            }
        }
        return 0;
    }

    static class Source {
        String name,url; Source(String n,String u){name=n;url=u;}
    }
    static class PriceResult {
        boolean ok; double price; PriceResult(boolean o,double p){ok=o;price=p;}
    }

    public static class PriceChart extends View {
        Paint p = new Paint(3);
        ArrayList<String> names=new ArrayList<>();
        ArrayList<Double> vals=new ArrayList<>();
        int[] colors={0xffffb300,0xff42a5f5,0xff66bb6a,0xffef5350,0xffab47bc,0xff26c6da};
        public PriceChart(Context c){super(c); p.setTypeface(Typeface.DEFAULT);}
        void clear(){names.clear();vals.clear();invalidate();}
        void addPoint(String n,double v){names.add(n);vals.add(v);invalidate();}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            c.drawColor(Color.rgb(20,24,30));
            p.setTextSize(34);p.setColor(Color.WHITE);c.drawText("مقایسه قیمت",30,48,p);
            if(vals.size()==0)return;
            double min=Collections.min(vals), max=Collections.max(vals);
            if(max==min){max=min+1;}
            float left=45, top=85, right=getWidth()-30, bottom=getHeight()-65;
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);
            for(int i=0;i<vals.size();i++){
                float x=left+(right-left)*i/Math.max(1,vals.size()-1);
                float y=(float)(bottom-(vals.get(i)-min)/(max-min)*(bottom-top));
                p.setColor(colors[i%colors.length]);
                if(i==0)c.drawCircle(x,y,6,p); else {
                    float px=left+(right-left)*(i-1)/Math.max(1,vals.size()-1);
                    float py=(float)(bottom-(vals.get(i-1)-min)/(max-min)*(bottom-top));
                    c.drawLine(px,py,x,y,p); c.drawCircle(x,y,6,p);
                }
                p.setStyle(Paint.Style.FILL);p.setTextSize(24);
                c.drawText(names.get(i),Math.max(10,x-45),bottom+35,p);
                p.setStyle(Paint.Style.STROKE);
            }
            p.setStyle(Paint.Style.FILL);
        }
    }
}
